// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables

import 'package:flutter/material.dart';

class Feed extends StatelessWidget {
  const Feed({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
        alignment: Alignment.center,
        height: 1000,
        child: ListView(
          children: [
            ListTile(
                leading: CircleAvatar(
                    backgroundImage: NetworkImage(
                  "https://static.wikia.nocookie.net/the-seven-husbands-of-evelyn-hugo/images/9/90/EvelynHugoFANART.jpg/revision/latest?cb=20221126173120",
                )),
                title: Text("evelynhugo"),
                subtitle: Row(
                  children: [],
                ),
                onTap: () {
                  Navigator.pushNamed(context, '/conversa');
                }),
            Image.network(
                "https://images.unsplash.com/photo-1661956600684-97d3a4320e45?ixlib=rb-4.0.3&ixid=M3wxMjA3fDF8MHxlZGl0b3JpYWwtZmVlZHw2fHx8ZW58MHx8fHx8&auto=format&fit=crop&w=500&q=60"),
            ListTile(
              leading: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(onPressed: () {}, icon: Icon(Icons.favorite)),
                  IconButton(
                      onPressed: () {},
                      icon: Icon(Icons.chat_bubble_outline_rounded)),
                  IconButton(onPressed: () {}, icon: Icon(Icons.send)),
                ],
              ),
              trailing:
                  IconButton(onPressed: () {}, icon: Icon(Icons.bookmark)),
            ),
            ListTile(
              subtitle: Text("a monique escrevendo minha historia de vida"),
            ),
            ListTile(
                leading: CircleAvatar(
                    backgroundImage: NetworkImage(
                  "https://www.google.com/url?sa=i&url=https%3A%2F%2Foglobo.globo.com%2Fcultura%2Fmusica%2Fnoticia%2F2023%2F05%2Flana-del-rey-especialistas-e-fas-analisam-fascinio-exercido-pela-cantora-que-e-a-principal-atracao-do-mita-festival.ghtml&psig=AOvVaw1N393vaqtJcUiKgmZDGoSg&ust=1686763712114000&source=images&cd=vfe&ved=0CA4QjRxqFwoTCID-0tHiwP8CFQAAAAAdAAAAABAD",
                )),
                title: Text("lanadelrey"),
                subtitle: Row(
                  children: [],
                ),
                onTap: () {
                  Navigator.pushNamed(context, '/conversa');
                }),
            Image.network(
                "https://images.unsplash.com/photo-1661956600684-97d3a4320e45?ixlib=rb-4.0.3&ixid=M3wxMjA3fDF8MHxlZGl0b3JpYWwtZmVlZHw2fHx8ZW58MHx8fHx8&auto=format&fit=crop&w=500&q=60"),
            ListTile(
              leading: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(onPressed: () {}, icon: Icon(Icons.favorite)),
                  IconButton(
                      onPressed: () {},
                      icon: Icon(Icons.chat_bubble_outline_rounded)),
                  IconButton(onPressed: () {}, icon: Icon(Icons.send)),
                ],
              ),
              trailing:
                  IconButton(onPressed: () {}, icon: Icon(Icons.bookmark)),
            ),
            ListTile(
              subtitle: Text("a monique escrevendo minha historia de vida"),
            ),
            ListTile(
                leading: CircleAvatar(
                    backgroundImage: NetworkImage(
                  "https://static.wikia.nocookie.net/the-seven-husbands-of-evelyn-hugo/images/9/90/EvelynHugoFANART.jpg/revision/latest?cb=20221126173120",
                )),
                title: Text("Evelyn"),
                subtitle: Row(
                  children: [],
                ),
                onTap: () {
                  Navigator.pushNamed(context, '/conversa');
                }),
            Image.network(
                "https://images.unsplash.com/photo-1661956600684-97d3a4320e45?ixlib=rb-4.0.3&ixid=M3wxMjA3fDF8MHxlZGl0b3JpYWwtZmVlZHw2fHx8ZW58MHx8fHx8&auto=format&fit=crop&w=500&q=60"),
            ListTile(
              leading: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(onPressed: () {}, icon: Icon(Icons.favorite)),
                  IconButton(
                      onPressed: () {},
                      icon: Icon(Icons.chat_bubble_outline_rounded)),
                  IconButton(onPressed: () {}, icon: Icon(Icons.send)),
                ],
              ),
              trailing:
                  IconButton(onPressed: () {}, icon: Icon(Icons.bookmark)),
            ),
            ListTile(
              subtitle: Text("a monique escrevendo minha historia de vida"),
            ),
            ListTile(
                leading: CircleAvatar(
                    backgroundImage: NetworkImage(
                  "https://static.wikia.nocookie.net/the-seven-husbands-of-evelyn-hugo/images/9/90/EvelynHugoFANART.jpg/revision/latest?cb=20221126173120",
                )),
                title: Text("Evelyn"),
                subtitle: Row(
                  children: [],
                ),
                onTap: () {
                  Navigator.pushNamed(context, '/conversa');
                }),
            Image.network(
                "https://images.unsplash.com/photo-1661956600684-97d3a4320e45?ixlib=rb-4.0.3&ixid=M3wxMjA3fDF8MHxlZGl0b3JpYWwtZmVlZHw2fHx8ZW58MHx8fHx8&auto=format&fit=crop&w=500&q=60"),
            ListTile(
              leading: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(onPressed: () {}, icon: Icon(Icons.favorite)),
                  IconButton(
                      onPressed: () {},
                      icon: Icon(Icons.chat_bubble_outline_rounded)),
                  IconButton(onPressed: () {}, icon: Icon(Icons.send)),
                ],
              ),
              trailing:
                  IconButton(onPressed: () {}, icon: Icon(Icons.bookmark)),
            ),
            ListTile(
              subtitle: Text("a monique escrevendo minha historia de vida"),
            ),
            ListTile(
                leading: CircleAvatar(
                    backgroundImage: NetworkImage(
                  "https://static.wikia.nocookie.net/the-seven-husbands-of-evelyn-hugo/images/9/90/EvelynHugoFANART.jpg/revision/latest?cb=20221126173120",
                )),
                title: Text("Evelyn"),
                subtitle: Row(
                  children: [],
                ),
                onTap: () {
                  Navigator.pushNamed(context, '/conversa');
                }),
            Image.network(
                "https://i2-prod.manchestereveningnews.co.uk/incoming/article26774361.ece/ALTERNATES/s1200c/1_Taylor-Swift-The-Eras-Tour-Concert-Arlington-Texas-United-States-31-Mar-2023.jpg"),
            ListTile(
              leading: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(onPressed: () {}, icon: Icon(Icons.favorite)),
                  IconButton(
                      onPressed: () {},
                      icon: Icon(Icons.chat_bubble_outline_rounded)),
                  IconButton(onPressed: () {}, icon: Icon(Icons.send)),
                ],
              ),
              trailing:
                  IconButton(onPressed: () {}, icon: Icon(Icons.bookmark)),
            ),
            ListTile(
              subtitle: Text("a monique escrevendo minha historia de vida"),
            ),
            ListTile(
                leading: CircleAvatar(
                    backgroundImage: NetworkImage(
                  "https://portalpopline.com.br/wp-content/uploads/2023/03/Taylor-Swift-3.png",
                )),
                title: Text("Evelyn"),
                subtitle: Row(
                  children: [],
                ),
                onTap: () {
                  Navigator.pushNamed(context, '/conversa');
                }),
            Image.network(
                "https://i2-prod.manchestereveningnews.co.uk/incoming/article26774361.ece/ALTERNATES/s1200c/1_Taylor-Swift-The-Eras-Tour-Concert-Arlington-Texas-United-States-31-Mar-2023.jpg"),
            ListTile(
              leading: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(onPressed: () {}, icon: Icon(Icons.favorite)),
                  IconButton(
                      onPressed: () {},
                      icon: Icon(Icons.chat_bubble_outline_rounded)),
                  IconButton(onPressed: () {}, icon: Icon(Icons.send)),
                ],
              ),
              trailing:
                  IconButton(onPressed: () {}, icon: Icon(Icons.bookmark)),
            ),
            ListTile(
              subtitle:
                  Text("foi um prazer cantar essa noite pra vcs queridos"),
            ),
          ],
        ));
  }
}